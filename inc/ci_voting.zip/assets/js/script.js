/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var baseurl = 'http://localhost/ci_survey/';
var rdata;
$(document).ready(function(){
   
   $('.vote').click(function(){

       someid = $(this).attr('id').substring(6);
       $.ajax({
           url: baseurl+'survey_module/get_questions',
           data: {id:someid},
           type: 'POST',
           success: function(data){ 
              $('#flot-pie-chart').html('');
              Morris.Bar({
                element: 'flot-pie-chart',
                data: data,
                xkey: 'label',
                ykeys: ['value'],
                labels: ['votes'],
                barColors: ['rgb(77, 167, 77)']
              }).on('click', function(i, row){
                console.log(i, row);
              });
           },
           error: function(){
               alert("An error occured please try again");
           }
       });
       
       
   });
   
        pollid = $('#pollid').val();
       $.ajax({
           url: baseurl+'poll/get_polls',
           data: {id:pollid},
           type: 'POST',
           success: function(data){ 
              $('#chart').html('');
              Morris.Bar({
                element: 'chart',
                data: data,
                xkey: 'label',
                ykeys: ['value'],
                labels: ['votes'],
                barColors: ['rgb(77, 167, 77)']
              }).on('click', function(i, row){
                console.log(i, row);
              });
           }
       });
   
   
   
});
    var client = new ZeroClipboard($(".copy"));
    
    
/*
 * document.getElementById("opt_A").onchange = function(){
    var reader = new FileReader();
    reader.onload = function(e){
        document.getElementById("optA").src = e.target.result;
    };

    reader.readAsDataURL(this.files[0]);
};

document.getElementById("opt_B").onchange = function(){
    var reader = new FileReader();
    reader.onload = function(e){
        document.getElementById("optB").src = e.target.result;
    };

    reader.readAsDataURL(this.files[0]);
};

document.getElementById("opt_C").onchange = function(){
    var reader = new FileReader();
    reader.onload = function(e){
        document.getElementById("optC").src = e.target.result;
    };

    reader.readAsDataURL(this.files[0]);
};

document.getElementById("opt_D").onchange = function(){
    var reader = new FileReader();
    reader.onload = function(e){
        document.getElementById("optD").src = e.target.result;
    };

    reader.readAsDataURL(this.files[0]);
};
 */
