<div class="col-sm-3 no-padding no-margin">
    <div class="card card-underline ">
	<div class="card-head">
	    <header class="card-header"><i class="fa fa-fw fa-bell"></i> School Reports</header>
	</div>
	<div class="card-body">
	    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
	    </p>
	</div>
    </div><!-- end of first div -->

    <div class="card card-underline">
	<div class="card-head">
	    <header><i class="fa fa-fw fa-graduation-cap"></i> News Letter and School Calendar</header>
	</div>
	<div class="card-body">
	    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
	    </p>
	</div>
    </div><!-- end of first div -->
    
    <div class="card card-underline">
	<div class="card-head">
	    <header><i class="fa fa-fw fa-graduation-cap"></i> Announcements</header>
	</div>
	<div class="card-body">
	    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
	    </p>
	    <hr>
	    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
	    </p>
	    <hr>
	    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
	    </p>
	    <hr>
	    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
	    </p>
	    <hr>
	</div>
    </div><!-- end of first div -->
</div>
<div class="col-sm-9">
    <div class="card card-type-blog-masonry card-underline">
	<div class="card-head">
	    <header class="h3">SUG election currently on</header>
	</div>
	<div class="card-body">
	    <img src="assets/img/p2.jpg" class="img-responsive img-thumbnail img-rounded pull-left"  style="margin-right:15px;"/>
	    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
	</div>
    </div>
    <div class="card card-type-blog-masonry card-underline">
	<div class="card-head">
	    <header class="h3">Vice Chancellors Address</header>
	</div>
	<div class="card-body">
	    <img src="assets/img/p1.jpg" class="img-responsive img-thumbnail img-rounded pull-left"  style="margin-right:15px;"/>
	    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
	</div>
    </div>
</div>