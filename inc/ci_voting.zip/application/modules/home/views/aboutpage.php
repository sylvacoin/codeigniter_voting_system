<!-- Title -->
    <h1>About Us</h1>
    <h4>Your first online vehicle licensing website</h4>
    <!-- Sub title -->
    <p>Architecto numquam perspiciatis commodi laboriosam quod debitis placeat maxime quaerat soluta quia porro dicta sunt nemo voluptates!</p>

    
</div> <!-- /.col-md-7 -->

    <div class="col-md-5">

      <!-- Images showcase -->
      <figure>
          <img class="img-iPhone" src="<?= base_url('assets/images/iphone/2.png') ?>" alt="" height="855px">
      </figure>