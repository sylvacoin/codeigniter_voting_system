<ul class="header-nav header-nav-options">
    <li class="dropdown">
	<a href="<?= base_url() ?>" class="btn btn-default">
	   Home
	</a>
    </li><!--end .dropdown -->
    <li class="dropdown">
	<a href="<?= base_url('about') ?>" class="btn btn-default">
	   About
	</a>
    </li><!--end .dropdown -->
    <li class="dropdown">
	<a href="<?= base_url('poll') ?>" class="btn btn-default">
	   Vote
	</a>
    </li><!--end .dropdown -->
    <li class="dropdown">
	<a href="<?= base_url('contact') ?>" class="btn btn-default">
	   Contact
	</a>
    </li><!--end .dropdown -->

<?php if (! isset($this->session->user_id)): ?>
    <li class="dropdown">
	<a href="<?= base_url('auth/login') ?>" class="btn btn-default">
	   Login / Register
	</a>
    </li><!--end .dropdown -->
</ul>
<?php else: ?>
</ul><!--end .header-nav-options -->
<ul class="header-nav header-nav-profile">
    <li class="dropdown">
	<a href="javascript:void(0);" class="dropdown-toggle ink-reaction" data-toggle="dropdown">
	    <img src="<?= base_url() ?>assets/img/avatar2.png" alt="" />
	    <span class="profile-info">
		<?= isset( $this->session->username ) ? $this->session->username : $this->session->regno ?>
		<small><?= isset( $this->session->role) ? $this->session->role : 'No role'  ?></small>
	    </span>
	</a>
	<ul class="dropdown-menu animation-dock">
	    <li><a href="<?= base_url('dashboard') ?>">Go to Dashboard</a></li>
	    <li><a href="<?= base_url('users/profile') ?>">My profile</a></li>
	    <li class="divider"></li>
	    <?php $this->session->role == 'administrator' ? $url = 'backend' : $url = 'login'; ?>
	    <li><a href="<?= site_url('auth/logout?redirect=auth/'.$url) ?>"><i class="fa fa-fw fa-power-off text-danger"></i> Logout</a></li>
	</ul><!--end .dropdown-menu -->
    </li><!--end .dropdown -->
</ul><!--end .header-nav-profile -->

<?php endif; ?>