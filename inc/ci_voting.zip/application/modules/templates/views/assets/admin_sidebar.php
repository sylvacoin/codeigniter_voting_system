<div class="menubar-fixed-panel">
    <div>
	<a class="btn btn-icon-toggle btn-default menubar-toggle" data-toggle="menubar" href="javascript:void(0);">
	    <i class="fa fa-bars"></i>
	</a>
    </div>
    <div class="expanded">
	<a href="<?= site_url() ?>">
	    <span class="text-lg text-bold text-primary ">MATERIAL&nbsp;ADMIN</span>
	</a>
    </div>
</div>
<div class="menubar-scroll-panel">

    <!-- BEGIN MAIN MENU -->
    <ul id="main-menu" class="gui-controls">

	<!-- BEGIN DASHBOARD -->
	<li>
	    
	    <a href="<?= site_url('dashboard') ?>" <?= $this->uri->segment(2) == '' ? 'class="active"' : ''  ?>>
		<div class="gui-icon"><i class="md md-home"></i></div>
		<span class="title">Dashboard</span>
	    </a>
	</li><!--end /menu-li -->
	<?php if ( $this->session->role == 'administrator'): ?>
	<li>
	    <a href="<?= site_url('poll/create_poll') ?>" <?= in_array($this->uri->segment(2), ['create_poll','create_image_poll','create_text_poll']) ? 'class="active"' : ''  ?>>
		<div class="gui-icon"><i class="md md-equalizer"></i></i></div>
		<span class="title">New Poll</span>
	    </a>
	</li><!--end /menu-li -->
	<li>
	    <a href="<?= site_url('poll/view_poll') ?>" <?= $this->uri->segment(2) == 'view_poll' ? 'class="active"' : ''  ?>>
		<div class="gui-icon"><i class="md md-archive"></i></div>
		<span class="title">View Polls</span>
	    </a>
	</li><!--end /menu-li -->
	<li>
	    <a href="<?= site_url('department/new_department') ?>" <?= $this->uri->segment(2) == 'new_department' ? 'class="active"' : ''  ?>>
		<div class="gui-icon"><i class="md md-account-child"></i></i></div>
		<span class="title">View departments</span>
	    </a>
	</li><!--end /menu-li -->
	<li>
	    <a href="<?= site_url('users/clearance') ?>" <?= $this->uri->segment(2) == 'clearance' ? 'class="active"' : ''  ?>>
		<div class="gui-icon"><i class="md md-done-all"></i></i></div>
		<span class="title">Election Clearance</span>
	    </a>
	</li><!--end /menu-li -->
	<?php else: ?>
	<li>
	    <a href="<?= site_url('users/profile') ?>" <?= $this->uri->segment(2) == 'profile' ? 'class="active"' : ''  ?>>
		<div class="gui-icon"><i class="md md-account-box"></i></div>
		<span class="title">My Profile</span>
	    </a>
	</li><!--end /menu-li -->
	<li>
	    <a href="<?= site_url('poll/') ?>">
		<div class="gui-icon"><i class="md md-done-all"></i></div>
		<span class="title">Vote</span>
	    </a>
	</li><!--end /menu-li -->
	<?php endif; ?>
	<li>
	    <a href="<?= site_url('auth/change_password') ?>" <?= $this->uri->segment(2) == 'change_password' ? 'class="active"' : ''  ?>>
		<div class="gui-icon"><i class="md md-lock"></i></div>
		<span class="title">Change password</span>
	    </a>
	</li><!--end /menu-li -->
	<li>
	    <a href="<?= site_url('auth/logout') ?>" >
		<div class="gui-icon"><i class="fa fa-power-off"></i></div>
		<span class="title">Log out</span>
	    </a>
	</li><!--end /menu-li -->
	
    </ul><!--end .main-menu -->
    <!-- END MAIN MENU -->

    <div class="menubar-foot-panel">
	<small class="no-linebreak hidden-folded">
	    <span class="opacity-75">Copyright &copy; <?= date('Y') ?></span> <strong>Dimconnect</strong>
	</small>
    </div>
</div><!--end .menubar-scroll-panel-->
