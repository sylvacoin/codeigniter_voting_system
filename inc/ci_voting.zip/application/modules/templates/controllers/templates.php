 <?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of templates
 *
 * @author Code X
 */
class templates extends MX_Controller{
    public function __construct() {
        parent::__construct();
    }
    
    function admin($data){
        $this->load->view('backend', $data);
    }
    
    function printMedia($data){
        $this->load->view('print', $data);
    }
    
    function one_col($data){
        $this->load->view('one_col', $data);
    }
    
    function two_col_lnav($data){
        $this->load->view('two_col_lnav',$data);
    }
    
    function home($data){
        $this->load->view('frontend', $data);
    }
}
