<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of mdl_level
 *
 * @author Code X
 */
class mdl_level extends CI_Model{
    function __construct() {
        parent::__construct();
    }
    
    function create($data){
        return $this->db->insert('level', $data);
    }
    
    function delete($id){
        $this->db->where('level_id',$id);
        return $this->db->delete('level');
    }
    
    function update($data, $id){
        $this->db->where('level_id', $id);
        return $this->db->update('level', $data);
    }
    
    function fetch_levels($id = NULL){
        if ($id != NULL ){
            $result = $this->db->get_where('level', ['level_id'=> $id]);
            return $result->row();
        }
        
        $result = $this->db->get('level');
        return $result->result();
    }
}
