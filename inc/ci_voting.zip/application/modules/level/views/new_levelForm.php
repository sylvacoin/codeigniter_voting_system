<?php
 if ($this->session->flashdata('success') != NULL) {
     echo $this->session->flashdata('success');
 }
 if ($this->session->flashdata('error') != NULL) {
     echo $this->session->flashdata('error');
 }
?>
<form method="post" action="<?= site_url('level/new_level') ?>">
    </p><label for="lvlname">Level: </label>
        <input type="text" name="lvl"/></p>
        <input type="hidden" name="lvl_url" value="<?= uri_string() ?>"/>
    <p><input type="submit" value="Create Level" name="btnSubmit" /></p>
</form>