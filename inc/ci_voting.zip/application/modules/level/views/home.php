<?=
        anchor(site_url('level/new_level'), 'Create Level') 
        ?> | 
<?php 
if ($this->session->flashdata('error') != NULL){
    echo $this->session->flashdata('error');
}
if ($this->session->flashdata('success') != NULL){
    echo $this->session->flashdata('success');
}
foreach($levels as $lvl){
    echo '<li>'.$lvl->level_type.' '.anchor(site_url('level/edit_level/'.$lvl->level_id), 'edit').' '
            .  anchor(site_url('level/delete_level/'.$lvl->level_id), 'Delete').'</li>';
}