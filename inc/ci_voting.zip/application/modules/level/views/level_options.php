<select name="<?= $name ?>" <?= $attr ?>>
    <?php foreach($levels as $lvl): ?>
    <?php $select = ($selected == $lvl->level_id ? 'selected="selected"' : '' )?>
    <option value="<?= $lvl->level_id ?>" <?= $select ?>><?= $lvl->level_type ?></option>
    <?php endforeach; ?>
</select>