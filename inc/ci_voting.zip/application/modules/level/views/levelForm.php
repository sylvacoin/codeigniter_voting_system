<?php
 if ($this->session->flashdata('success') != NULL) {
     echo $this->session->flashdata('success');
 }
 if ($this->session->flashdata('error') != NULL) {
     echo $this->session->flashdata('error');
 }
?>
<form method="post" action="">
    </p><label for="lvlname">Level: </label>
        <input type="text" name="lvl" value="<?= isset($lvl->level_type) ? $lvl->level_type : set_value('lvl') ?>"/></p>
        <input type="hidden" name="lvl_url" value="<?= uri_string() ?>"/>
    <p><input type="submit" value="Create Level" name="submit" /></p>
</form>