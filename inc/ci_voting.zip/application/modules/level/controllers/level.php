<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of level
 *
 * @author Code X
 */
class level extends MX_Controller{
    function __construct() {
        parent::__construct();
    }
    
    function index(){
        redirect(site_url('level/view_levels'));
    }
    
    function new_level(){
        if ($this->input->post('btnSubmit') != NULL){
            $data['level_type'] = $this->input->post('lvl');
            $this->load->model('mdl_level');
            if ($this->mdl_level->create($data)){
                $this->session->set_flashdata('success', 'New Level was added successfully');
            }else{
                $this->session->set_flashdata('error', 'Level was not added Please try again');
            }
            redirect(site_url($this->input->post('lvl_url')));
        }
        $this->load->view('new_levelForm');
    }
    
    function edit_level($id){
        $this->load->model('mdl_level');
        if ($this->input->post('submit') != NULL){
            $data['level_type'] = $this->input->post('lvl');
           if ($this->mdl_level->update($data, $id)){
               $this->session->set_flashdata('success','Level name was updated successfully');
               redirect('level/view_levels');
           }
        }
        
        $data['lvl'] = $this->mdl_level->fetch_levels($id);
        $this->load->view('levelForm', $data);
    }
    
    function delete_level($id){
        $this->load->model('mdl_level');
        if ($this->mdl_level->delete($id)){
            $this->session->set_flashdata('success','Level was deleted succesfully');
        }else{
            $this->session->set_flashdata('error','Level was not deleted please try again later');
        }
        redirect(site_url('level/view_levels'));
    }
    
    function view_levels($id = NULL){
        $this->load->model('mdl_level');
        $data['levels'] = '';
        if ($id == NULL){ // load all Levels
            $data['levels'] = $this->mdl_level->fetch_levels();
        }else{
            $data['levels'] = $this->mdl_level->fetch_levels($id);
        }
        
        $this->load->view('home', $data);
    }
    
    function fetch_lvl_opt($name, $attr = NULL, $selected = NULL){
       $data['name'] = $name;
       $data['attr'] = $attr;
       $data['selected'] = $selected;
       
       $this->load->model('mdl_level');
       $data['levels'] = $this->mdl_level->fetch_levels();
       $this->load->view('level_options', $data);
    }
    
    function get_level_by_id($id){
        $this->load->model('mdl_level');
        $result = $this->mdl_level->fetch_levels($id);
        return $result->level_type;
    }
}
