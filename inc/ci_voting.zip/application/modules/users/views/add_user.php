
<div class="col-sm-6">
    <br/>
    <span class="text-lg text-bold text-primary">REGISTER NEW ACCOUNT</span>
    <br/><br/>
    <div class="card">
	<div class="card-body">
	    <?= validation_errors( '<div class="alert alert-danger alert-dismissable"><button class="close" data-dismiss="alert">&times;</button>', '</div>' ) ?>
	    <?php
	    if ( $this->session->flashdata( 'error' ) != NULL ) {
		echo '<div class="alert alert-danger alert-dismissable"><button class="close" data-dismiss="alert">&times;</button>' . $this->session->flashdata( 'error' ) . '</div>';
	    }

	    if ( $this->session->flashdata( 'success' ) != NULL ) {
		echo '<div class="alert alert-success alert-dismissable"><button class="close" data-dismiss="alert">&times;</button>' . $this->session->flashdata( 'success' ) . '</div>';
	    }
	    ?>
	    <?= form_open( 'users/signup' ) ?>

            <div class="form-group floating-label">
		<?= form_input( 'fname', ( isset( $fname ) ? $fname : set_value( 'fname' ) ), 'class="form-control" placeholder="Enter Full Name"' ) ?>
            </div> <!-- /.form-group -->

            <div class="form-group floating-label">
		<?= form_input( 'uname', ( isset( $uname ) ? $uname : set_value( 'uname' ) ), 'class="form-control" placeholder="Enter Username"' ) ?>
            </div> <!-- /.form-group -->
	    <div class="form-group floating-label">
	    <?= Modules::run('department/fetch_dept_opt','dept','class="form-control"' ), 
		    (isset($dept)?$dept:  set_value('dept'))?>
            </div> <!-- /.form-group -->

	    <div class="form-group floating-label">
		<?php $options = ['200','300','400'] ?>
		<?= form_dropdown( 'level', $options, ( isset( $level ) ? $level : set_value( 'level' ) ), 'class="form-control"' ) ?>
            </div> <!-- /.form-group -->
	    
	    <div class="form-group floating-label">
		<?= form_input( 'regno', ( isset( $regno ) ? $regno : set_value( 'regno' ) ), 'class="form-control" placeholder="Enter Registration Number"' ) ?>
            </div> <!-- /.form-group -->

            <div class="form-group floating-label">
		<?= form_input( 'email', ( isset( $email ) ? $email : set_value( 'email' ) ), 'class="form-control" placeholder="Enter email Address"' ) ?>
            </div> 
            <div class="form-group floating-label">
		<input type="password" name="pswd" placeholder="Enter password"   class="form-control" />
            </div>

            <div class="form-group floating-label">
		<input type="password" name="pswd1" placeholder="Confirm password"   class="form-control" />
            </div>
            <div class="form-group floating-label">
		<?= form_submit( 'submit', 'Register', 'class="btn-block btn style-primary btn-md"' ) ?>
            </div>
	    <?= form_close() ?>
	    <?= anchor( 'auth/login', 'Already have an account?', 'style="display: block; padding-top:50px;"' ) ?>
	</div>
    </div>
</div>
<div class="col-sm-6">
    <br/>
    <br/><br/>
    <img src="../assets/img/pic4.jpg" width="100%" height="100%"/>
</div>