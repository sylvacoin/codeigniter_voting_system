<img src=" <?= base_url('assets/uploads/thumb/'.$file_name) ?> " />
<input type="hidden" name="ïmage" value="<?= base_url('assets/uploads/thumb/'.$file_name) ?>" />