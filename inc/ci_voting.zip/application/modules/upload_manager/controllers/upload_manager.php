<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Upload_manager extends MX_Controller
{
    
function __construct() {
parent::__construct();
$this->load->library('image_lib');
}

function index(){
    $this->load->view('upload_form');
}

function upload($img){
    $this->load->helper('string');
    $result = $this->upload_handler($img);
    $file_name=$result['upload_data']['file_name'];
    $file_ext = $result['upload_data']['file_ext'];
    $this->resize_image('./assets/uploads/'.$file_name, $file_ext);
    $imgpath = $this->imgname.'_thumb'.$file_ext;
    return $imgpath;
//    $data['file_name'] = $this->imgname.'_thumb'.$file_ext;
//    $this->load->view('result', $data);
}

function upload_multiple($imgs){
    $this->load->helper('string');
    $result = $this->multi_upload_handler($imgs);
   
    foreach ($result as $image ){
        
        $file_name= $image['file_name'];
        $file_ext = $image['file_ext'];
        $this->resize_image('./assets/uploads/'.$file_name, $file_ext);
        $imgpath[] = $this->imgname.'_thumb'.$file_ext;
    }
    return $imgpath;
}

function upload_handler($img, $encrypt = FALSE)
{
    $config['upload_path']          = './assets/uploads/';
    $config['allowed_types']        = 'gif|jpg|png';
    $config['max_size']             = 2000;
    $config['max_width']            = 2500;
    $config['max_height']           = 2500;
    $config['overwrite']            = TRUE;
    $config['encrypt_name']         = $encrypt;
    

    $this->load->library('upload', $config);
    
    if ($this->upload->do_upload($img)){
	$data = array('upload_data' => $this->upload->data());
	return $data;
    }else{
        $error = array('error' => $this->upload->display_errors().'  '.$config['upload_path']);
        $this->load->view('upload_errors', $error);
    }
    
}

function multiple_upload($img)
{
    $this->load->helper('string');
    
    $data = [];
    $config['upload_path']          = './assets/uploads/';
    $config['allowed_types']        = 'gif|jpg|png';
    $config['max_size']             = 2000;
    $config['overwrite']            = FALSE;
    
    $this->load->library('upload');
    $num_of_files_to_upload = count( $_FILES[$img]['name']);
    for ( $f = 0; $f < $num_of_files_to_upload; $f++):
	$_FILES['userfile']['name']	= $_FILES[$img]['name'][$f];
	$_FILES['userfile']['type']	= $_FILES[$img]['type'][$f];
	$_FILES['userfile']['tmp_name'] = $_FILES[$img]['tmp_name'][$f];
	$_FILES['userfile']['size']	= $_FILES[$img]['size'][$f];
	$_FILES['userfile']['error']	= $_FILES[$img]['error'][$f];
	
	$config['file_name'] = $_FILES[$img]['name'][$f];
	
	$this->upload->initialize( $config );
	if ( ! $this->upload->do_upload() ):
	    $data[$f]['error'] =  $this->upload->display_errors();
	    $data[$f]['upload_data'] = NULL;
	else:
	    $data[$f]['error'] =  NULL;
	    $data[$f]['upload_data'] = $this->upload->data();
	    $data[$f]['upload_data']['thumb'] = $this->resize_image('./assets/uploads/'.$this->upload->data('file_name'), $this->upload->data('file_ext'));
	endif;
	
    endfor;
    
    return $data;
	    
}

function resize_image($image_path, $ext){
    $this->imgname = random_string();
    $config['image_library'] = 'gd2';
    $config['new_image'] = './assets/uploads/thumb/'.$this->imgname.$ext;
    $config['source_image'] = $image_path;
    $config['create_thumb'] = TRUE;
    $config['maintain_ratio'] = TRUE;
    $config['width']         = 128; 
    $config['height']       = 160;

    $this->image_lib->initialize($config);

    if ( ! $this->image_lib->resize())
    {
        return $this->image_lib->display_errors();
    }else{
	unlink($image_path);
	return 'assets/uploads/thumb/'.$this->imgname.'_thumb'.$ext;
	
    }
    
    //$this->image_lib->clear(); 
}

}
