<div class="col-sm-5 col-sm-offset-3">
<?= validation_errors('<div class="alert alert-dismissable alert-danger">', '</div>'); ?>
<form class="form-horizontal" role="form" method="post" action="">
        <div class="form-group">
            <label class="control-label" for="surveyname">Select Type of Poll:</label>
            <select name="selector" class="form-control" id="selector">
                <option value="0">Select</option>
                <option value="text">Text Poll</option>
                <option value="image">Image Poll</option>
            </select>
        </div>
        <div class="form-group">
              <button type="submit" class="btn btn-primary col-sm-12">Continue</button>
        </div>
</form>
</div>