<div class="card">
    <div class="card-body">
<?php
if ($this->session->flashdata('error') != NULL) {
    echo '<div class="alert alert-danger alert-dismissable"><button class="close" data-dismiss="alert">&times;</button>'.$this->session->flashdata('error').'</div>';
}

if ($this->session->flashdata('success') != NULL) {
    echo '<div class="alert alert-success alert-dismissable"><button class="close" data-dismiss="alert">&times;</button>'.$this->session->flashdata('success').'</div>';
}
?>

<a href="<?= site_url('poll/create_poll/'.$this->uri->segment(3)) ?>" class="btn btn-primary btn-sm" style="margin-bottom: 5px;"><i class="fa fa-plus"></i> Create a Poll</a>
<table class="table no-margin">
    <thead>
        <tr>
            <th>S/N</th>
            <th>POLL</th>
            <th>&nbsp;</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($questions->num_rows() > 0): $i=1; foreach($questions->result() as $question): ?>
        <tr>
            <td><?= $i++ ?></td>
            <td><?= $question->question  ?></td>
            <td>
                <?= anchor('poll/view_votes/'.$question->poll_id, "<i class=\"fa fa-signal\"></i> View Votes")  ?> | 
                <?= anchor('poll/edit_poll/'.count(unserialize($question->options)).'/'.$question->poll_id, "<i class=\"fa fa-edit\"></i> Edit Poll") ?> |  
		<?php if ( $question->status == 1 ): ?>
                <?= anchor('poll/stop_poll/'.$question->poll_id, "<i class=\"fa fa-pause\"></i> Stop" ); ?>
		<?php else: ?> 
		<?= anchor('poll/start_poll/'.$question->poll_id, "<i class=\"fa fa-play\"></i> Start" ); ?>
		<?php endif ?> |
		<?= anchor('poll/delete_poll/'.$question->poll_id, "<i class=\"fa fa-trash\"></i> Delete", 'class="text-danger"' ); ?>
            </td>
        </tr>
        <?php endforeach; else: ?>
        <tr>
            <td colspan="6"> No questions yet </td>
	    </tr> 
        <?php endif; ?>
    </tbody>
</table>
</div>
</div>

<script>
    //var client = new ZeroClipboard( $('.copy') )
</script>