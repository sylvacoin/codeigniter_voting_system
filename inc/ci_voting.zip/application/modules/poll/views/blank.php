<?php if ( !is_numeric( $this->uri->segment(3) ) ):?>
<?= form_open() ?>
<?= form_input('no_contestants'); ?>
<?= form_submit('btnGenerate','GO'); ?>
<?php else: ?>
<?= form_close(); ?>
<?= form_open_multipart(  current_url() ) ?>
<?php if ( is_numeric( $this->uri->segment(3) ) ): 
   for( $i=1; $i<= $this->uri->segment(3); $i++): ?>
<p>Contestant <?= $i ?> Image : <?= form_upload('images[]','', "id='file$i' class='uploader'"); ?></p>
<p class="text-center" style="display: block;"><img src="<?php echo (isset($image)?$image: base_url() .'assets/img/static/default.jpg' ) ?> " data-sid="<?= $i ?>" height="80px" width="80px" id="preview<?= $i ?>" class="img-responsive img-rounded img-thumbnail" alt="profile image" /></p>
	
<?php endfor; ?>
<?= form_submit('submit','Upload'); ?>
<?php else: 
    redirect('polls/create_image_poll'); 
endif; ?>
<?= form_close(); ?>
<?php endif; ?>

<script>
    function preview(input)
    {
	if ( input.files && input.files[0])
	{
	    var elemID = $(input).attr('id');
	    id = elemID.substring(4);
	    var reader = new FileReader();
	    reader.onload = function(e){
		$('#preview'+id).attr('src', e.target.result);
	    }
        reader.readAsDataURL(input.files[0]);
	}
    }
    
    $('.uploader').change(function(){
	preview(this);
    });
</script>