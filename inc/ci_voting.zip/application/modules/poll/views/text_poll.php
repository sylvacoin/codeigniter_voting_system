<div class="card">
    <div class="card-body">
    <?php if ( !is_numeric( $this->uri->segment( 3 ) ) ): ?>
    <div class="row">
        <div class="col-sm-12">
    	<div class="card card-underline">
    	    <div class="card-head">
    		<header>Select number of contestants to participate in poll</header>
    	    </div>
    	    <div class="card-body">
    		<form class="form-horizontal" role="form" method="post" action="" enctype="multipart/form-data" accept-charset="utf-8">
    		    <input type="hidden"  name="poll_type" value="image" />
    		    <div class="form-group">
    			<label for="">Enter number of contestants</label>
			    <?= form_input( 'no_contestants', '', 'class="form-control"' ) ?>
    		    </div>
    		    <div class="form-group">
    			<button type="submit" name="btnGenerate" class="btn style-primary col-sm-4 col-sm-offset-4">Generate</button>
    		    </div>
    		</form>
    	    </div>
    	</div>
        </div>
    </div>
<?php else: ?>
<div class="col-sm-6 col-sm-offset-3">
<?= validation_errors('<div class="alert alert-dismissable alert-danger">', '</div>'); ?>
<form class="form-horizontal" role="form" method="post" action="">
    <input type="hidden"  name="poll_type" value="text" />
    <div class="form-group">
        <label class="control-label" for="surveyname">Question:</label>
        <textarea class="form-control"  name="question" placeholder="Enter Poll Question" id="question"><?= ( isset($question)? $question :set_value('question')) ?></textarea>
    </div>
   
    <?php 
    $no_contestants = 0;
    if ( is_numeric( $this->uri->segment( 3 ) ) && $this->uri->segment(2) != 'edit_poll' ): 
	$no_contestants = $this->uri->segment(3);
    elseif (is_numeric( $this->uri->segment( 3 ) ) && $this->uri->segment(2) == 'edit_poll' ):
	$no_contestants = $this->uri->segment(3);
    else:
	redirect( 'poll/create_text_poll' );
    endif;
    ?>
    
    <?php for ( $i = 1; $i <= $no_contestants; $i++ ): ?>
    <div class="form-group">
        <label class="control-label" for="optA">Option <?= $i ?>:</label>
        <input type="text" class="form-control" 
	       value="<?= ( isset($opt[$i])? $opt[$i] : set_value('opt['.$i.']')) ?>" 
	       name="opt[<?= $i; ?>]" placeholder="Contestant <?= $i ?>">
    </div>
    <?php endfor; ?>
   
    <input type="hidden" class="form-control" value="text" name="type">
    <div class="form-group">
          <button type="submit" class="btn btn-primary col-sm-12">Create Poll</button>
    </div>

</form>
</div>
<?php endif; ?>
</div>
</div>