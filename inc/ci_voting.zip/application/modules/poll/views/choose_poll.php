<div class="row">

    <!-- BEGIN ALERT - REVENUE -->
    <div class="col-md-3 col-sm-6 col-md-offset-3">
	<div class="card">
	    <div class="card-body no-padding">
		<div class="alert alert-callout alert-info no-margin">
		    <p><strong class=" center-block text-center text-success text-lg">Photo Poll <i class="fa fa-photo fa-5x"></i></strong></p>
		    <span class="opacity-50">use photos as options</span>
		    <p class="text-center"><a href="<?= site_url('poll/create_image_poll') ?>" class="btn btn-accent-bright">Get Started</a></p>
		    <div class="stick-bottom-left-right">
			
		    </div>
		</div>
	    </div><!--end .card-body -->
	</div><!--end .card -->
    </div><!--end .col -->
    <!-- END ALERT - REVENUE -->
    
    <div class="col-md-3 col-sm-6">
	<div class="card">
	    <div class="card-body no-padding">
		<div class="alert alert-callout alert-info no-margin">
		    <p>
			<strong class="text-center center-block text-success text-lg">Text Poll <i class="fa fa-keyboard-o fa-5x"></i></strong></p>
		    <span class="opacity-50">use text as options</span>
		    <p class="text-center"><a href="<?= site_url('poll/create_text_poll') ?>" class="btn btn-accent-bright">Get Started</a></p>
		    <div class="stick-bottom-left-right">
			
		    </div>
		</div>
	    </div><!--end .card-body -->
	</div><!--end .card -->
    </div><!--end .col -->
    <!-- END ALERT - REVENUE -->


</div>