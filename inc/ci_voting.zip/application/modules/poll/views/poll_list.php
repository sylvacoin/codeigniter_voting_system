<div class="card card-underline">
    <div class="card-head card-head-lg">
	<header class="opacity-100">List of running elections</header>
    </div>
    <div class="card-body">
<?php
if ($this->session->flashdata('error') != NULL) {
    echo '<div class="alert alert-danger alert-dismissable"><button class="close" data-dismiss="alert">&times;</button>'.$this->session->flashdata('error').'</div>';
}

if ($this->session->flashdata('success') != NULL) {
    echo '<div class="alert alert-success alert-dismissable"><button class="close" data-dismiss="alert">&times;</button>'.$this->session->flashdata('success').'</div>';
}
?>
	<div class="alert alert-info">
	    Select a position to vote for 
	</div>
    
        <?php if ($questions->num_rows() > 0): $i=1; foreach($questions->result() as $question): ?>
	<a href="<?= $question->link ?>">
	<div class="card card-bordered">
	    <div class="card-body">
		<p><?= $question->question  ?></p>
	    </div>
	</div>
	</a>
        <?php endforeach; else: ?>
        <div class="card card-bordered">
	    <div class="card-body">
		<p> No election available check back later</p>
	    </div>
	</div>
        <?php endif; ?>
    
</div>
</div>

<script>
    //var client = new ZeroClipboard( $('.copy') )
</script>