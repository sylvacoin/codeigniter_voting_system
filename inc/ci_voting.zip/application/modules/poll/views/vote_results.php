<div class="row">
    <header class="h1">Poll Result</header>
    <?php
    if ($this->session->flashdata('error') != NULL) {
        echo '<div class="alert alert-danger alert-dismissable h4"><button class="close" data-dismiss="alert">&times;</button>'.$this->session->flashdata('error').'</div>';
    }

    if ($this->session->flashdata('success') != NULL) {
        echo '<div class="alert alert-success alert-dismissable h4"><button class="close" data-dismiss="alert">&times;</button>'.$this->session->flashdata('success').'</div>';
    }
    ?>
</div>
<div class="row">
<div class="col-sm-12" id="result">
        <?php if (isset($poll) && count($poll) > 0): $i = 1;?> 
        <input type="hidden" name="pollID" value="<?= $poll->poll_id ?>"/>
	<div class="card card-underline">
	    <div class="card-head">
		<header class="text-center"><?= $poll->question ?></header>
	    </div>
	    <div class="card-body">
	
	    <?php 
	    $options = unserialize( $poll->options );
	    
	    if ( $poll->poll_type == 'image') : 
	    foreach ( $options as $candidate ): ?>
	    <div class="col-sm-6">
	    <div class="card">
		<div class="card-body no-padding">
		    <div class="alert alert-callout alert-info no-margin">
			<img src="<?= base_url().$candidate['photo'] ?>" class="img-responsive center-block"/>
			<h4 class="text-center">
			    <span class="opacity-50"><?= $candidate['name'] ?></span><br>
			    <span class="opacity-50">(<?= $results[@++$e]['result'] ?>%)</span><br>
			</h4>

		    </div>
		</div><!--end .card-body -->
	    </div><!--end .card -->
	    </div>
	    <?php endforeach ?>
	    <?php else: ?>
	    <ul class="list divider-full-bleed">
		<?php foreach ( $options as $candidate ): ?>
		<li class="tile">
		    <a class="tile-content ink-reaction" href="#2">
			<div class="tile-icon">
			    <img src="<?= base_url() ?>assets/img/avatar2.png" alt="" />
			</div>
			<div class="tile-text"><?= $candidate ?></div>
		    </a>
		    <span class="btn btn-flat ink-reaction">
			<?= $results[@++$k]['result'] ?>%
		    </span>
		</li>
		<?php endforeach ?>
	    </ul>
	    <?php endif; ?>

	    </div>
	    <div class="card-foot">
		<button id="showChart" class="btn btn-info"> View Chart </button>
	    </div>
	</div>
    
    <?php else: ?>
	<div class="card">
	    <div class="card-body no-padding">
		<div class="alert alert-callout alert-info no-margin">
		    <p class="text-center">This poll does not exist.</p>
		</div>
	    </div><!--end .card-body -->
	</div><!--end .card -->
    <?php endif; ?>
</div>
<div class="col-sm-12" id="chart">
    <div class="card card-underline">
	<div class="card-head">
	    <header>Vote Result Chart</header>
	</div>
	<div class="card-body">
            <div id="barchart">

            </div>
	    <button id="showResult" class="btn btn-info"> View Result </button>
	</div>
    </div>
</div>
</div>

<script src="<?= base_url() ?>assets/js/morris.js"></script>
<script src="<?= base_url() ?>assets/js/raphael.min.js"></script>
<script>
	$('#chart').hide();
	$('#showChart').click(function(){
	    $('#result').hide();
	    $.ajax({
	    url: "<?= base_url('poll/get_ajax_result') ?>",
	    data:{id:<?= $this->uri->segment(3) ?>},
	    type:'POST',
	    success:function(data)
	    {
		mdata = JSON.parse(data);
		console.log(mdata);
		// Morris Bar demo
		if ($('#barchart').length > 0) {
		    Morris.Bar({
			    element: 'barchart',
			    data: mdata,
			    xkey: "name",
			    ykeys: ['result'],
			    labels: ['votes'],
			    barColors:['#2196f3']
		    });
		}

	    }
	    });
	    $('#chart').show();
	});
    
    $('#showResult').click(function(){
	$('#chart').hide();
	$('#result').show();
    });
    
    </script>
    
   