<div class="card card-underline">
    <div class="card-head">
	<header>Voting Results</header>
    </div>
    <div class="card-body">
	<div class="col-sm-6">
	    <div class="list-group">
		<li class="list-group-item h4"><?= $question->question ?></li>
		<ul class="list-group h6">
		    <?php foreach ( $results as $option ): ?>
    		    <li class="list-group-item">Contestant <?= @ ++$i; ?>. <?= $option[ 'name' ] ?> <span class="badge badge-primary"><?= $option[ 'result' ] ?>%</span></li>
		    <?php endforeach; ?>
		</ul>
	    </div>
	</div>
	<div class="col-sm-6">
	    <table width="80%" class="table h5">
		<?php foreach ( $results as $option ): ?>
    		<tr>
    		    <td style="width:50%; margin-bottom: 5px;">Contestant <?= @ ++$a; ?>. <?= $option[ 'name' ] ?></td>
    		    <td><img src="<?= base_url( 'assets/img/red.jpg' ) ?>" width="<?= $option[ 'result' ] * 2 ?>" height="20px"></td>
    		</tr>
		<?php endforeach; ?>
	    </table>
	</div>
    </div>
</div>

