<div class="col-sm-12">
    <?php
    if ($this->session->flashdata('error') != NULL) {
        echo '<div class="alert alert-danger alert-dismissable h4"><button class="close" data-dismiss="alert">&times;</button>'.$this->session->flashdata('error').'</div>';
    }

    if ($this->session->flashdata('success') != NULL) {
        echo '<div class="alert alert-success alert-dismissable h4"><button class="close" data-dismiss="alert">&times;</button>'.$this->session->flashdata('success').'</div>';
    }
    ?>
    <?php if (isset($poll) && count($poll) > 0):?> 
        <input type="hidden" name="pollID" value="<?= $poll->poll_id ?>"/>
	<h4><?= $poll->question ?></h4>
	<?php 
	$options = unserialize( $poll->options );
	if ( $poll->poll_type == 'image') : 
	foreach ( $options as $candidate ): ?>
	<div class="col-sm-6">
	<div class="card">
	    <div class="card-body no-padding">
		
		<div class="alert alert-callout alert-info no-margin">
		    <img src="<?= base_url().$candidate['photo'] ?>" class="img-responsive center-block"/>
		    <h4 class="text-center">
			<span class="opacity-50"><?= $candidate['name'] ?></span>
		    </h4>

		    <div class="stick-bottom-left-right">
			<p>
			    <a href="<?= site_url( 'poll/vote/'.$this->uri->segment(3).'/'.@++$i ) ?>" class="btn btn-info">
				Vote
			    </a>
			</p>
		    </div>
		</div>
		
	    </div><!--end .card-body -->
	</div><!--end .card -->
	</div>
	<?php endforeach ?>
	<?php else: ?>
	<ul class="list divider-full-bleed">
	    <?php foreach ( $options as $candidate ): ?>
	    <li class="tile">
		<a class="tile-content ink-reaction" href="#2">
		    <div class="tile-icon">
			<img src="<?= base_url() ?>assets/img/avatar2.png" alt="" />
		    </div>
		    <div class="tile-text"><?= $candidate ?></div>
		</a>
		<a class="btn btn-flat ink-reaction" href="<?= site_url( 'poll/vote/'.$this->uri->segment(3).'/'.@++$g ) ?>">
		    <i class="fa fa-check-circle "></i> vote
		</a>
	    </li>
	    <?php endforeach ?>
	</ul>
	<?php endif; ?>
    
    
    <?php else: ?>
	<div class="card">
		<div class="card-body no-padding">
		    <div class="alert alert-callout alert-info no-margin">
			<p class="text-center">This poll does not exist.</p>
		    </div>
		</div><!--end .card-body -->
	    </div><!--end .card -->
    <?php endif; ?>
</div>