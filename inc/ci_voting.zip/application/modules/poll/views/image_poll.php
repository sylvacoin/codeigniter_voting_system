<?php if ( !is_numeric( $this->uri->segment( 3 ) ) ): ?>
    <div class="row">
        <div class="col-sm-12">
    	<div class="card card-underline">
    	    <div class="card-head">
    		<header>Select number of contestants to participate in poll</header>
    	    </div>
    	    <div class="card-body">
    		<form class="form-horizontal" role="form" method="post" action="" enctype="multipart/form-data" accept-charset="utf-8">
    		    <input type="hidden"  name="poll_type" value="image" />
    		    <div class="form-group">
    			<label for="">Enter number of contestants</label>
			    <?= form_input( 'no_contestants', '', 'class="form-control"' ) ?>
    		    </div>
    		    <div class="form-group">
    			<button type="submit" name="btnGenerate" class="btn style-primary col-sm-4 col-sm-offset-4">Generate</button>
    		    </div>
    		</form>
    	    </div>
    	</div>
        </div>
    </div>
<?php else: ?>
    <div class="card">
        <div class="card-body">

	    <?php
	    if ( $this->session->flashdata( 'error' ) != NULL ) {
		echo '<div class="alert alert-danger alert-dismissable"><button class="close" data-dismiss="alert">&times;</button>' . $this->session->flashdata( 'error' ) . '</div>';
	    }

	    if ( $this->session->flashdata( 'success' ) != NULL ) {
		echo '<div class="alert alert-success alert-dismissable"><button class="close" data-dismiss="alert">&times;</button>' . $this->session->flashdata( 'success' ) . '</div>';
	    }
	    ?>
    	<?php 
	$no_contestants = 0;
	if ( is_numeric( $this->uri->segment( 3 ) ) && $this->uri->segment(2) != 'edit_poll' ): 
	    $no_contestants = $this->uri->segment(3);
	elseif (is_numeric( $this->uri->segment( 3 ) ) && $this->uri->segment(2) == 'edit_poll' ):
	    $no_contestants = $this->uri->segment(3);
	else:
	    redirect( 'poll/create_image_poll' );
	endif;
	?>
    	<form class="form-horizontal" role="form" method="post" action="<?= current_url() ?>" enctype="multipart/form-data" accept-charset="utf-8">
    	    <input type="hidden"  name="poll_type" value="image" />
    	    <div class="form-group">
    		<label class="control-label" for="surveyname">Question:</label>
    		<textarea class="form-control"  name="question" placeholder="Enter Survey Question" id="question"><?= ( isset( $question ) ? $question : set_value( 'question' )) ?></textarea>
    	    </div>
    	    <ul class="list-comments">
    <?php for ( $i = 1; $i <= $this->uri->segment( 3 ); $i++ ): 
	    if ( isset($images) ):
	    $photo = $images[$i]['photo'];
	    $name = $images[$i]['name'];
	    endif;
	?>
		<li>
		    <div class="card style-default-light">
			<div class="comment-avatar">
			    <img src="<?php echo (isset( $photo ) ? base_url().$photo : base_url() . 'assets/img/avatar1.jpg') ?>" 
				data-sid="<?= $i ?>" class="img-circle" width="58px" height="58px" id="preview<?= $i ?>" alt="profile image"/>
			</div>
			<div class="card-body">
			    <div class="row">
				
				
				<div class="col-sm-3">
				    <div class="form-group">
					<label for="file<?= $i ?>">Contestant <?= $i ?> photo:</label>
					<?= form_upload( 'images[]', '', "id='file$i' class='uploader' required" ) ?>
				    </div>
				</div>
				<div class="col-sm-9">
				    <div class="form-group">
					<input type="text" class="form-control" name="names[<?= $i ?>]" placeholder="Contestant <?= $i ?> name" value="<?= isset($name)?$name:set_value('names['.$i.']') ?>" required>
				    </div>
				</div>
			    </div>
			</div>
		    </div>
		</li>
    <?php endfor; ?>
	    </ul>
	    <input type="hidden" class="form-control" value="image" name="type">
	    <div class="form-group">
		<button type="submit" name="submit" class="btn btn-primary col-sm-4 col-sm-offset-4">Add Question</button>
	    </div>
    	</form>
        </div>
    </div>
<?php endif; ?>

<script>
    function preview(input)
    {
        if (input.files && input.files[0])
        {
            var elemID = $(input).attr('id');
            id = elemID.substring(4);
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#preview' + id).attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    $('.uploader').change(function () {
        preview(this);
    });
</script>