<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class poll extends MX_Controller
{

function __construct() {
    parent::__construct();
    $this->load->model(["mdl_poll","mdl_result_module"]);
    $this->load->module('templates');
    $this->load->helper('text');
}

//========================PAGES======================
function index(){
    $this->db->where('status',1);
    $data['questions'] = $this->mdl_poll->get('poll_id');
    $data['view_file']= 'poll_list';
    $this->templates->home($data);
}

function create_image_poll( $count = NULL )
{
    if ( isset( $_POST['btnGenerate']) )
    {
	$c = $this->input->post('no_contestants');
	redirect('poll/create_image_poll/'.$c);
    }
    
    if (isset($_POST['submit']) && is_numeric($count) ) {
        $this->_img_submit_poll_data();
	redirect('poll/create_image_poll/'.$count, 'refresh');
    }
    
    $data['view_file'] = 'image_poll';
    $this->templates->admin($data);
}

function create_text_poll(){
    $this->form_validation->set_rules('question','Survey Question', 'required');
    $this->form_validation->set_rules('opt[1]','Option A', 'required');
    $this->form_validation->set_rules('opt[2]','Option B', 'required');
    
    if ( isset( $_POST['btnGenerate']) )
    {
	$c = $this->input->post('no_contestants');
	redirect('poll/create_text_poll/'.$c);
    }
    
    if ($this->form_validation->run($this) == true){
        $this->_txt_submit_poll_data();
        $this->_conditional_redirect('poll/view_poll', 'poll/view_my_poll');
    }
    $data['view_file'] = 'text_poll';
    $this->templates->admin($data);
}

function create_poll(){
    $data['view_file'] = 'choose_poll';
    $this->templates->admin($data);
}

function _conditional_redirect($admin_redirect, $user_redirect){
    if ($this->session->user_id == 'admin'){
        redirect($admin_redirect);
    }else{
        redirect($user_redirect);
    }
}

function view_poll(){
    $data['questions'] = $this->mdl_poll->get('poll_id');
    $data['view_file']= 'question_list';
    $this->templates->admin($data);
}

function view_my_poll(){
    $this->db->where('user_id', $this->session->user_id);
    $data['questions'] = $this->mdl_poll->get('poll_id');
    $data['view_file']= 'question_list';
    $this->templates->admin($data);
}

function get_polls(){
    $id = $this->input->post('id');
    //$data[] = $this->mdl_result_module->get_where_custom('question_id', $id)->row();
    $returned = $this->mdl_result_module->get_where_custom('poll_id', $id)->row();
    $data[] = array ('label'=>'Option A', 'value'=>$returned->A);
    $data[] = array ('label'=>'Option B', 'value'=>$returned->B);
    $data[] = array ('label'=>'Option C', 'value'=>$returned->C);
    $data[] = array ('label'=>'Option D', 'value'=>$returned->D);
    
    header('Content-Type: application/json');
    echo json_encode($data);
}

function edit_poll(){
    $this->form_validation->set_rules('question','Poll Question', 'required');
    if ( $this->input->post('type') == 'Text'){
    $this->form_validation->set_rules('opt[1]','Option A', 'required');
    $this->form_validation->set_rules('opt[2]','Option B', 'required');
    }
    
    $id = $this->uri->segment(4);
    
    //if not an edit, dont bother
    if (!is_numeric( $id))
    {
	redirect('poll/view_poll');
    }
    
    if ($this->form_validation->run($this) == TRUE) {
	$type = $this->input->post('type');
	if ( $type == 'image'){
	    $this->_img_submit_poll_data();
	}else{
	    $this->_txt_submit_poll_data();
	}
        $this->_conditional_redirect('poll/view_poll', 'poll/view_my_poll');
    }else{
        $data = $this->_get_poll_data_from_db($id);
        //print_r($data); die();
        if ( $data['poll_type'] == 'Text' ){
            $data['view_file'] = 'text_poll';
        }
        if ( $data['poll_type'] == 'image' ){
            $data['view_file'] = 'image_poll';
        }
        $this->templates->admin($data);
    }
}

function _txt_submit_poll_data(){
    $data = $this->_get_txt_poll_data_from_post();
    
    $id = $this->uri->segment(4);
    if (is_numeric($id)){
        $this->_update($id, $data, 'mdl_poll');
    }else{
	$data['createdTime'] = time();
	$data['link'] = site_url('poll/vote/'.  $data['createdTime'] );
        $this->_insert($data, 'mdl_poll');
        $rdata= $this->_get_result_data();
        $this->_insert($rdata, 'mdl_result_module');
    }
}

function _img_submit_poll_data(){
    $data = $this->_get_img_poll_data_from_post();
    $extra = $data[2]; unset($data[2]);
    $id = $this->uri->segment(4);
    if (is_numeric($id)){
        $this->_update($id, $data[0], 'mdl_poll');
    }else{
	$data[0]['createdTime'] = time();
	$data[0]['link'] = site_url('poll/vote/'.  $data[0]['createdTime'] );
        $this->_insert($data[0], 'mdl_poll', $extra, 'success');
        $rdata = $this->_get_result_data();
	$rdata['results']= $data[1];
        $this->_insert($rdata, 'mdl_result_module');
    }
}

function view_votes($poll_id){
    $data['question'] = $this->mdl_poll->get_where_custom('poll_id', $poll_id)->row();
    $data['results'] = $this->get_poll_votes($poll_id);

    $data['view_file']= 'vote_preview';
    $this->templates->admin($data);
}

function view_result($poll_id){
    $data['poll'] = $this->mdl_poll->get_where_custom('poll_id', $poll_id)->row();
    $data['results'] = $this->get_poll_votes($poll_id);

    $data['view_file']= 'vote_results';
    $this->templates->home($data);
}

function get_ajax_result()
{
    $id = $this->input->post('id');
    $data = $this->get_poll_votes($id, true);
    echo json_encode($data);
}

function get_poll_votes($id, $ajax = false){
    $this->db->join('poll','poll.poll_id=result.poll_id');
    $serialized_result = $this->mdl_result_module->get_where_custom('result.poll_id', $id)->row();
    
    $result = unserialize( $serialized_result->results );
    $data = unserialize( $serialized_result->options );
    
    $votes=[];
    $i=1;$a=0;
    $total = array_sum($result);
    foreach( $result as $p => $voteCount):
	
	if ( $ajax == true ) {
	    if ( $serialized_result->poll_type == 'image'):
	    $votes[$a]['name'] = $data[$i]['name'];
	    $votes[$a++]['result'] = $voteCount;
	    else:
	    $votes[$a]['name'] = $data[$i];
	    $votes[$a++]['result'] = $voteCount;
	    endif;
	}else{
	    if ( $serialized_result->poll_type == 'image'):
	    $votes[$i]['name'] = $data[$i]['name'];
	    $votes[$i]['result'] = ($voteCount != 0) ? floor((($voteCount * 100)/ $total)): 0;
	    else:
	    $votes[$i]['name'] = $data[$i];
	    $votes[$i]['result'] = ($voteCount != 0) ? floor((($voteCount * 100)/ $total)): 0;
	    endif;
	}
	$i++;
    endforeach;
    return $votes;
}

function vote($key = '', $option = NULL){
    if ( !is_numeric($this->session->user_id))
    {
	$this->session->set_flashdata('error','You have to log in first in other to vote');
	redirect('auth/login?redirect=poll/vote/'.$key);
    }
    
    $result = $this->mdl_poll->get_where_custom('createdTime', $key );
    if ( $result->num_rows() > 0 ) {
	$poll_id = $result->row()->poll_id;
	if ( !is_numeric( $option)) {
	    $data['poll'] = $this->mdl_poll->get_where($poll_id)->row();
	}
    }
    
    if (is_numeric($key) && is_numeric($option)) {
        $this->_update_existing_result($poll_id, $option);
        redirect('poll/view_result/'.$poll_id);
    }
    
    $data['view_file'] = 'question_preview';
    $this->templates->home($data);
}

function start_poll($id){
    $data['status'] = 1;
    $this->_update($id, $data, 'mdl_poll');
    $this->_conditional_redirect('poll/view_poll', 'poll/view_my_poll');
}

function stop_poll($id){
    $data['status'] = 0;
    $this->_update($id, $data, 'mdl_poll');
    $this->_conditional_redirect('poll/view_poll', 'poll/view_my_poll');
}

function delete_poll($id){
    $this->_delete($id, 'mdl_poll');
    $this->_delete($id, 'mdl_result_module');
    $this->_conditional_redirect('poll/view_poll', 'poll/view_my_poll');
}

function _update_existing_result($poll_id, $answer){
    $uid = $this->session->user_id;
    $can_vote = $this->session->eligible;
    if ( $can_vote != 1 )
    {
	$this->session->set_flashdata('error', 'sorry you have not been cleared to vote');
	redirect('poll/view_result/'.$poll_id);
    }
    
    $this->db->where(array(
	'voter_id' => $uid,
	'poll_id'  => $poll_id
    ));
    $r = $this->db->get('vote_list');
    if (  $r->num_rows() > 0 )
    {
	$this->session->set_flashdata('error', 'You are not allowed or cannot vote two times');
	redirect('poll/view_result/'.$poll_id);
    }
    
    $result = $this->mdl_result_module->get_where_custom('poll_id', $poll_id);
    if ( $result->num_rows() > 0 )
    {
	$votes = unserialize( $result->row()->results ); 
	$votes[$answer] += 1;
	$data['results'] = serialize($votes);
	$result = $this->db->update('result', $data, ['result_id'=> $result->row()->result_id] );
	//die( print_r($result->affected_rows()));
	
	if ($result )
	{
	    $this->db->insert('vote_list', array(
		'poll_id' => $poll_id,
		'voter_id' => $uid,
		'vote_time' => time(),
	    ));
	    $this->session->set_flashdata('success', 'Congratulations your vote was successful wish your choice the best. See the result of the vote below');
	}
    }

}

//========================HELPERS====================

function _get_txt_poll_data_from_post(){
    $data['question'] = $this->input->post('question');
    $options = $this->input->post('opt'); $i=1;
    foreach( $options  as $opt)
    {
	$opts[$i++] = $opt;
    }
    $data['options'] = serialize($opts);
    $data['poll_type'] = $this->input->post('poll_type');
    $data['user_id'] = $this->session->user_id;
    
    return $data;
}

function _get_img_poll_data_from_post(){
    $i=1; $mycount = 0; $result=[]; $options=[];
    $contestants = $this->input->post('names');
    $uploaded = Modules::run('upload_manager/multiple_upload', 'images'); 
        foreach($uploaded as $img  )
	{
	    if ( $img['error'] != NULL )
	    {
		$mycount += 1;
		continue;
	    }
	    
	    $options[$i]['photo'] = $img['upload_data']['thumb'];
	    $options[$i]['name'] = $contestants[$i];
	    $result[$i++] = 0;
	}
	
	$data[0]['question'] = $this->input->post('question');
	$data[0]['poll_type'] = 'image';
	$data[0]['user_id'] = $this->session->user_id;
	$data[0]['options'] = serialize($options);
	$data[0]['link'] =  site_url('poll/vote/'.  url_title( $data[0]['question'], '-', true));
	$data[1] = serialize($result);
	$data[2] = $mycount > 0 ? 'One or more images was not uploaded please check again':'';
	
	return $data;
}

function _get_poll_data_from_db($id){
    $returned = $this->mdl_poll->get_where($id)->row();
    $data['question'] = $returned->question;
    if ( $returned->poll_type == 'image') {
	$data['images'] = unserialize( $returned->options );
    }else{
	$data['opt'] = unserialize( $returned->options );
    }
    $data['poll_type'] = $returned->poll_type;
    $data['poll_id'] = $returned->poll_id;
    return $data;
}

function _get_result_data(){
    $data['poll_id'] = $this->db->insert_id();
    return $data;
}


function get($order_by) {
    $query = $this->mdl_poll->get($order_by);
    return $query;
}

function get_with_limit($limit, $offset, $order_by) {
    $query = $this->mdl_poll->get_with_limit($limit, $offset, $order_by);
    return $query;
}

function get_where($id) {
    $query = $this->mdl_poll->get_where($id);
    return $query;
}

function get_where_custom($col, $value) {

$query = $this->mdl_poll->get_where_custom($col, $value);
return $query;
}

function _insert($data, $module, $extra = NULL, $condition = NULL) {
    if ( $condition == 'success'){
	$success = $extra;
    }else{
	$error = $extra;
    }
    
    if ($this->$module->_insert($data)) {
        $this->session->set_flashdata('success', 'Poll was added successfully. '.(isset($success)?$success:''));
    }else{
        $this->session->set_flashdata('error', 'There was an error, Poll was not added please try again later '.(isset($error)?$error:''));
    }
}

function _update($id, $data, $module) {
    if ($this->$module->_update($id, $data)) {
        $this->session->set_flashdata('success', 'update successful');
    }else{
        $this->session->set_flashdata('error', 'update not successful please try again later');
    }
}

function _delete($id, $module) {
    if ($this->$module->_delete($id)) {
        $this->session->set_flashdata('success', 'deletion successful');
    }else{
        $this->session->set_flashdata('error', 'deletion not successful please try again later');
    }

}

function count_where($column, $value) {

$count = $this->mdl_poll->count_where($column, $value);
return $count;
}

function get_max() {

$max_id = $this->mdl_poll->get_max();
return $max_id;
}

function _custom_query($mysql_query) {

$query = $this->mdl_poll->_custom_query($mysql_query);
return $query;
}

}
