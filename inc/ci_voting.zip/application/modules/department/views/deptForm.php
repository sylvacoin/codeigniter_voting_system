<?php
 if ($this->session->flashdata('success') != NULL) {
     echo $this->session->flashdata('success');
 }
 if ($this->session->flashdata('error') != NULL) {
     echo $this->session->flashdata('error');
 }
?>
<form method="post" action="">
    <label for="deptname">Department: 
        <input type="text" name="deptname" value="<?= isset($dept->department) ? $dept->department : set_value('deptname') ?>"/>
    </label>
    <label for="nolvl">No of years: 
        <select name="nolvl">
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
        </select>
    </label>
    <input type="hidden" name="curr_url" value="<?= uri_string(); ?>"/>
    <input type="submit" name="submit" value="Update Department" />
</form>