<div class="row">
    <div class="page-header">
        <h1>View Departments</h1>
    </div>
<?= anchor(site_url('department/new_department'), 'New Department', 'class="btn btn-default"') ?> 
<div class="col-sm-8 col-sm-offset-2">
<?php 
if ($this->session->flashdata('error') != NULL){
    echo $this->session->flashdata('error');
}
if ($this->session->flashdata('success') != NULL){
    echo $this->session->flashdata('success');
} 
$i = 1;
?>
<table class="table table-condensed table-striped table-bordered">
    <tr>
        <th>S/N</th>
        <th>Department</th>
        <th colspan="2">Actions </th>
    </tr>
<?php foreach($departments as $dept): ?>
    <tr>
        <td><?= $i++ ?></td>
        <td><?= $dept->department ?></td>
        <td><?= anchor(site_url('department/edit_department/'.$dept->department_id), "<i class=\"fa fa-edit fa-fw\"></i>". ' edit') ?></td>
        <td><?= anchor(site_url('department/delete/'.$dept->department_id), "<i class=\"fa fa-trash fa-fw\"></i>". ' Delete') ?> </td>
    </tr>
<?php endforeach; ?>
</table>
    
</div>
</div>