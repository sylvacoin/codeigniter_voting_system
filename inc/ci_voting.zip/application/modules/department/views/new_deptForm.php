<div class="col-sm-6">
<div class="card card-underline">
    <div class="card-head">
	<header>
	    <small>Add Department</small>
	</header>
    </div>
    <div class="card-body">
<div class="row">
    
<?php
 if ($this->session->flashdata('success') != NULL) {
     echo $this->session->flashdata('success');
 }
 if ($this->session->flashdata('error') != NULL) {
     echo $this->session->flashdata('error');
 }
?>
<form method="post" action="<?= site_url('department/create') ?>" class="form-horizontal">
    
    <div class="form-group">
        <label for="" class="control-label col-sm-4">Department Name: </label>
        <div class="col-sm-8">
            <input type="text" name="deptname" class="form-control" value="<?= isset($dept->department) ? $dept->department : set_value('deptname') ?>"/>
        </div>
    </div>
    <div class="form-group">
        <label for="" class="control-label col-sm-4">No of Years: </label>
        <div class="col-sm-8">
        <select name="nolvl" class="form-control">
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
        </select>
        </div>
    </div>
    <div class="form-group">
    <input type="hidden" name="curr_url" value="<?= uri_string(); ?>"/>
    <button type="submit" class="col-sm-offset-4 col-sm-4 btn btn-info">Create Department</button>
    </div>
        
</form>
</div>
    </div> 
</div>
</div>
<div class="col-sm-6">
<div class="card card-underline">
    <div class="card-head">
	<header>
	    <small>Departments</small>
	</header>
    </div>
    <div class="card-body">
<?php 
if ($this->session->flashdata('error') != NULL){
    echo $this->session->flashdata('error');
}
if ($this->session->flashdata('success') != NULL){
    echo $this->session->flashdata('success');
} 
$i = 1;
?>
<table class="table table-condensed table-striped table-bordered">
    <tr>
        <th>S/N</th>
        <th>Department</th>
        <th colspan="2">Actions </th>
    </tr>
<?php foreach($departments as $dept): ?>
    <tr>
        <td><?= $i++ ?></td>
        <td><?= $dept->department ?></td>
        <td><?= anchor(site_url('department/edit_department/'.$dept->department_id), "<i class=\"fa fa-edit fa-fw\"></i>". ' edit') ?></td>
        <td><?= anchor(site_url('department/delete/'.$dept->department_id), "<i class=\"fa fa-trash fa-fw\"></i>". ' Delete') ?> </td>
    </tr>
<?php endforeach; ?>
</table>
    
</div>
</div>
</div>