<select name='<?= $name ?>' <?= $attr ?>>
    <option value="0">-- Select Department --</option>
    <?php foreach($depts as $dept): ?>
    <?php $select = ($selected == $dept->department_id ? 'selected = "Selected"' : "") ?>
    <option value='<?= $dept->department_id ?>' <?= $select ?>> <?= $dept->department; ?></option> 
    <?php endforeach; ?>
</select>