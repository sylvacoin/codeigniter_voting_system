<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of mdl_department
 *
 * @author Code X
 */
class mdl_department extends CI_Model{
    function __construct() {
        parent::__construct();
    }
    
    function create($data){
        return $this->db->insert('department', $data);
    }
    
    function fetch_departments($data = NULL){
        if ($data == NULL){
            $result = $this->db->get('department');
            return $result->result();
        }
        $result = $this->db->get_where('department', ['department_id'=>$data]);
        return $result->row();
    }
    
    function delete($data){
        return $this->db->delete('department', ['department_id'=>$data]);
    }
    
    function update($data, $id){
        $this->db->where('department_id', $id);
        return $this->db->update('department', $data);
    }
}
