<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Department
 *
 * @author Code X
 */
class Department extends MX_Controller{
    //put your code here
    function __construct() {
        parent::__construct();
	$this->load->module('templates');
    }
    
    function index(){
        redirect('department/view_departments');
    }
 
    function new_department( $department_id = NULL ){
        $data['view_file'] = 'new_deptForm';
        $this->load->model('mdl_department');
        $data['departments'] = '';
        if ($department_id == NULL){ // load all departments
            $data['departments'] = $this->mdl_department->fetch_departments();
        }else{
            $data['departments'] = $this->mdl_department->fetch_departments($department_id);
        }
        $this->templates->admin($data);
    }
    
    function view_departments($department_id = NULL){
        $this->load->model('mdl_department');
        $data['departments'] = '';
        if ($department_id == NULL){ // load all departments
            $data['departments'] = $this->mdl_department->fetch_departments();
        }else{
            $data['departments'] = $this->mdl_department->fetch_departments($department_id);
        }
        
        $data['view_file'] = 'home';
        
        $this->templates->admin($data);
    }
    
    function create(){

        $url = $this->input->post('curr_url');
        $data['no_level'] = $this->input->post('nolvl');
        $data['department'] = $this->input->post('deptname');
        
        $this->load->model('mdl_department');
        if ($this->mdl_department->create($data)) {
            $this->session->set_flashdata('success', $data['department'].' was added as a new department');
            $data = [];
        }else{
            $this->session->set_flashdata('error', 'Unable to add new department please try again');
        }
        redirect(site_url($url));
    }
    
    function edit_department($id){
        $this->load->model('mdl_department');
        if ($this->input->post('submit') != NULL){
            $data['department'] = $this->input->post('deptname');
            $data['no_level'] = $this->input->post('nolvl');
           if ($this->mdl_department->update($data, $id)){
               $this->session->set_flashdata('success','Department name was updated successfully');
               redirect('department/view_departments');
           }
        }
        
        $data['dept'] = $this->mdl_department->fetch_departments($id);
        //$this->load->view('deptForm', $data);
        $data['view_file'] = 'deptForm';
        
        $this->templates->admin($data);
    }
    
    function delete($data){
        $this->load->model('mdl_department');
        if ($this->mdl_department->delete($data)){
            $this->session->set_flashdata('success','Department was deleted succesfully');
        }else{
            $this->session->set_flashdata('error','Department was not deleted please try again later');
        }
        redirect(site_url('department/view_departments'));
    }
    
    function fetch_dept_opt($name, $attribute, $selected = NULL){
        $data['name'] = $name;
        $data['attr'] = $attribute;
        $data['selected'] = $selected;
        
        $this->load->model('mdl_department');
        $data['depts'] = $this->mdl_department->fetch_departments();
        $this->load->view('dept_options', $data);
        
    }
    
    function get_department_by_id($id){
        $this->load->model('mdl_department');
        $returned = $this->mdl_department->fetch_departments($id);
        return $returned;
    }
}
