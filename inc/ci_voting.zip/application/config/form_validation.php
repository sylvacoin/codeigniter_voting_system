<?php
$config = array(
    'signup' => array(
            array( 
                'field'=>'fname', 
                'label'=>'Full Name', 
                'rules'=>'required'
            ),
            array( 
                'field'=>'uname', 
                'label'=>'Username', 
                'rules'=>'required'
            ),
	    array( 
		    'field'=>'dept', 
		    'label'=>'Department', 
		    'rules'=>'required'
		),
	    array( 
		    'field'=>'level', 
		    'label'=>'Level', 
		    'rules'=>'required'
		),
	    array( 
		    'field'=>'regno', 
		    'label'=>'regno', 
		    'rules'=>'required'
		),
            array( 
                'field'=>'email', 
                'label'=>'Email Address', 
                'rules'=>'required'
            ),
            array( 
                'field'=>'pswd',
                'label'=>'Password',
                'rules'=>'required'
            ),
            array( 
                'field'=>'pswd1',
                'label'=>'Password Confirmation',
                'rules'=>'required|matches[pswd]'
            )
    ),
    'login' => array(
            array(
                    'field' => 'regno',
                    'label' => 'Registration Number',
                    'rules' => 'required|callback_authenticate'
            ),
            array(
                    'field' => 'pswd',
                    'label' => 'Password',
                    'rules' => 'required'
            )
    ),
    'alogin' => array(
            array(
                    'field' => 'email',
                    'label' => 'Email Address',
                    'rules' => 'required|callback_authenticate_admin'
            ),
            array(
                    'field' => 'pswd',
                    'label' => 'Password',
                    'rules' => 'required'
            )
    ),
    'vehicle' => array(
            array(
                    'field' => 'model',
                    'label' => 'Car Model',
                    'rules' => 'required'
            ),
            array(
                    'field' => 'make',
                    'label' => 'Car Make',
                    'rules' => 'required'
            ),
            array(
                    'field' => 'quality',
                    'label' => 'Car Quality',
                    'rules' => 'required|alpha'
            ),
            array(
                    'field' => 'engNo',
                    'label' => 'Car Engine Number',
                    'rules' => 'required|max_length[10]|min_length[10]'
            ),
            array(
                    'field' => 'chassisNo',
                    'label' => 'Car Chassis Number',
                    'rules' => 'required|max_length[10]|min_length[10]'
            )
    ),
    'transfer' => array(
            array(
                    'field' => 'id',
                    'label' => 'Reciever Identification Number',
                    'rules' => 'required|callback_verifyid'
            ),
            array(
                    'field' => 'option',
                    'label' => 'Vehicle license',
                    'rules' => 'required'
            )
    ),
    'transfer2' => array(         
            array(
                    'field' => 'transID',
                    'label' => 'Transfer ID',
                    'rules' => 'required|callback_authenticate_transfer'
            )
    ),
    'track' => array(         
            array(
                    'field' => 'vid',
                    'label' => 'Vehicle ID',
                    'rules' => 'required|min_length[11]'
            )
    )
);